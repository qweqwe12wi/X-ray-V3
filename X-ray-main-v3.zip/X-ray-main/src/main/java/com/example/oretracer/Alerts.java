package com.example.oretracer;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;

/** Distância até o minério mais próximo + alerta de lava/buraco perto de você. */
public final class Alerts {
    private static int t = 0;
    private static boolean resolved = false;
    private static Method withFlag, noFlag;

    private Alerts() { }

    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (++t % 4 != 0) return;
        TracerConfig cfg = TracerConfig.get();

        if (cfg.dangerAlert) {
            Component danger = danger(mc);
            if (danger != null) {
                show(mc, danger);
                return;
            }
        }
        if (!cfg.enabled || !cfg.showDistance) return;

        BlockPos me = mc.player.blockPosition();
        // Prefere blocos reais (minério/cidade); se não tiver, mostra Deep Dark / caverna.
        OreScanner.Hit best = null, bestVirtual = null;
        double bd = Double.MAX_VALUE, bvd = Double.MAX_VALUE;
        for (OreScanner.Hit h : OreScanner.results()) {
            if (!cfg.isOn(h.ore())) continue;
            double d = h.pos().distSqr(me);
            if (h.ore().isVirtual()) {
                if (d < bvd) { bvd = d; bestVirtual = h; }
            } else if (d < bd) { bd = d; best = h; }
        }
        if (best == null) { best = bestVirtual; bd = bvd; }
        if (best == null) return;

        int blocks = (int) Math.round(Math.sqrt(bd));
        String txt = best.ore().label + ": " + blocks + " blocos " + compass(me, best.pos());
        if (best.count() > 1) txt += " (veia de " + best.count() + ")";
        if (best.lava()) txt += " - LAVA PERTO!";
        show(mc, Component.literal(txt).withStyle(best.lava() ? ChatFormatting.RED : ChatFormatting.AQUA));
    }

    /** Direção na bússola (N, NE, L, SE, S, SO, O, NO). No Minecraft, +X = leste e +Z = sul. */
    private static String compass(BlockPos me, BlockPos target) {
        double dx = target.getX() - me.getX();
        double dz = target.getZ() - me.getZ();
        if (Math.abs(dx) < 4 && Math.abs(dz) < 4) return "[aqui]";
        double ang = Math.toDegrees(Math.atan2(dx, -dz));
        if (ang < 0) ang += 360;
        String[] names = {"N", "NE", "L", "SE", "S", "SO", "O", "NO"};
        return "[" + names[(int) Math.round(ang / 45.0) % 8] + "]";
    }

    private static Component danger(Minecraft mc) {
        var level = mc.level;
        BlockPos feet = mc.player.blockPosition();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        for (int dx = -2; dx <= 2; dx++)
            for (int dy = -2; dy <= 1; dy++)
                for (int dz = -2; dz <= 2; dz++) {
                    p.set(feet.getX() + dx, feet.getY() + dy, feet.getZ() + dz);
                    if (level.hasChunkAt(p) && level.getBlockState(p).is(Blocks.LAVA)) {
                        return Component.literal("PERIGO: LAVA PERTO!")
                                .withStyle(ChatFormatting.RED, ChatFormatting.BOLD);
                    }
                }

        if (level.getBlockState(feet.below()).isAir()) return null; // no ar: não avisa buraco

        Vec3 look = mc.player.getViewVector(1f);
        double len = Math.sqrt(look.x * look.x + look.z * look.z);
        if (len < 0.2) return null;
        double lx = look.x / len, lz = look.z / len;

        for (int step = 1; step <= 2; step++) {
            int x = (int) Math.floor(feet.getX() + 0.5 + lx * step);
            int z = (int) Math.floor(feet.getZ() + 0.5 + lz * step);
            p.set(x, feet.getY(), z);
            if (!level.hasChunkAt(p) || !level.getBlockState(p).isAir()) continue;

            int air = 0;
            for (int d = 1; d <= 6; d++) {
                p.set(x, feet.getY() - d, z);
                if (!level.hasChunkAt(p) || p.getY() < level.getMinY()) break;
                if (!level.getBlockState(p).isAir()) break;
                air++;
            }
            if (air >= 4) {
                return Component.literal("CUIDADO: BURACO A FRENTE!")
                        .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
            }
        }
        return null;
    }

    /** Mostra texto na barra de ação (acima da hotbar), achando o método por reflexão. */
    private static void show(Minecraft mc, Component msg) {
        if (!resolved) {
            resolved = true;
            for (Method m : mc.player.getClass().getMethods()) {
                Class<?>[] p = m.getParameterTypes();
                String n = m.getName().toLowerCase();
                if (p.length == 1 && p[0] == Component.class && (n.contains("overlay") || n.contains("actionbar"))) {
                    noFlag = m;
                } else if (p.length == 2 && p[0] == Component.class && p[1] == boolean.class
                        && n.contains("message") && withFlag == null) {
                    withFlag = m;
                }
            }
        }
        try {
            if (noFlag != null) noFlag.invoke(mc.player, msg);
            else if (withFlag != null) withFlag.invoke(mc.player, msg, true);
        } catch (Throwable ignored) { }
    }
}
