package com.example.oretracer;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Tela 2: espessuras, só o mais próximo, veias, distância, alerta e alcance da lava. */
public class OptionsScreen extends Screen {
    private static final int[] THICK = {1, 2, 3, 4, 6, 8};
    private static final int[] LAVA = {1, 3, 5, 8};

    private final Screen parent;

    public OptionsScreen(Screen parent) {
        super(Component.literal("Ore Tracer - Opções"));
        this.parent = parent;
    }

    private static int next(int[] arr, int cur) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == cur) return arr[(i + 1) % arr.length];
        }
        return arr[0];
    }

    @Override
    protected void init() {
        TracerConfig cfg = TracerConfig.get();
        int w = Math.min(this.width - 16, 320);
        int x0 = (this.width - w) / 2;
        int half = (w - 4) / 2;
        int x1 = x0 + half + 4;
        int h = 18;
        int step = 22;
        int y = 8;

        this.addRenderableWidget(new StringWidget(x0, y, w, 12, this.title, this.font));
        y += 20;

        this.addRenderableWidget(Button.builder(Component.literal("Espessura da linha: " + cfg.lineWidth), b -> {
            cfg.lineWidth = next(THICK, cfg.lineWidth);
            b.setMessage(Component.literal("Espessura da linha: " + cfg.lineWidth));
        }).bounds(x0, y, half, h).build());
        this.addRenderableWidget(Button.builder(Component.literal("Espessura da borda: " + cfg.boxWidth), b -> {
            cfg.boxWidth = next(THICK, cfg.boxWidth);
            b.setMessage(Component.literal("Espessura da borda: " + cfg.boxWidth));
        }).bounds(x1, y, half, h).build());
        y += step;

        this.addRenderableWidget(Button.builder(flag("Só o mais próximo", cfg.onlyNearest), b -> {
            cfg.onlyNearest = !cfg.onlyNearest;
            b.setMessage(flag("Só o mais próximo", cfg.onlyNearest));
        }).bounds(x0, y, half, h).build());
        this.addRenderableWidget(Button.builder(flag("Agrupar veias", cfg.groupVeins), b -> {
            cfg.groupVeins = !cfg.groupVeins;
            b.setMessage(flag("Agrupar veias", cfg.groupVeins));
        }).bounds(x1, y, half, h).build());
        y += step;

        this.addRenderableWidget(Button.builder(flag("Distância na tela", cfg.showDistance), b -> {
            cfg.showDistance = !cfg.showDistance;
            b.setMessage(flag("Distância na tela", cfg.showDistance));
        }).bounds(x0, y, half, h).build());
        this.addRenderableWidget(Button.builder(flag("Alerta de perigo", cfg.dangerAlert), b -> {
            cfg.dangerAlert = !cfg.dangerAlert;
            b.setMessage(flag("Alerta de perigo", cfg.dangerAlert));
        }).bounds(x1, y, half, h).build());
        y += step;

        this.addRenderableWidget(Button.builder(Component.literal("Alcance da lava (acima): " + cfg.lavaRange), b -> {
            cfg.lavaRange = next(LAVA, cfg.lavaRange);
            b.setMessage(Component.literal("Alcance da lava (acima): " + cfg.lavaRange));
        }).bounds(x0, y, w, h).build());
        y += step + 4;

        this.addRenderableWidget(Button.builder(Component.literal("Voltar"), b -> this.onClose())
                .bounds(x0, y, w, h).build());
    }

    private static Component flag(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "SIM" : "NÃO"))
                .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.GRAY);
    }

    @Override
    public void onClose() {
        TracerConfig.get().save();
        OreScanner.requestRescan();
        if (this.minecraft != null) this.minecraft.setScreenAndShow(this.parent);
    }
}
