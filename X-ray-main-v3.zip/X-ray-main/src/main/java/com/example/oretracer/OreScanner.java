package com.example.oretracer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Varredura incremental: só blocos expostos, em poucos chunks por tick. */
public final class OreScanner {
    /** pos = bloco mais próximo (alvo da linha); min/max = caixa da veia; count = blocos na veia. */
    public record Hit(BlockPos pos, Ore ore, boolean lava, BlockPos min, BlockPos max, int count) { }
    private record Cell(int cx, int cz) { }

    private static final int CHUNKS_PER_TICK = 2;
    private static final int RESCAN_DELAY_TICKS = 60;

    private static final ArrayDeque<Cell> QUEUE = new ArrayDeque<>();
    private static final List<Hit> BUILDING = new ArrayList<>();
    private static volatile List<Hit> results = List.of();
    private static Set<Block> active = Set.of();
    private static int cooldown = 0;
    private static boolean scanBiome = false;
    private static boolean scanCave = false;
    private static BlockPos playerPos = BlockPos.ZERO;

    private OreScanner() { }

    public static List<Hit> results() {
        return results;
    }

    public static void requestRescan() {
        QUEUE.clear();
        BUILDING.clear();
        cooldown = 0;
    }

    public static void tick(Minecraft mc) {
        TracerConfig cfg = TracerConfig.get();
        if (!cfg.enabled || mc.level == null || mc.player == null) {
            QUEUE.clear();
            BUILDING.clear();
            results = List.of();
            return;
        }

        if (QUEUE.isEmpty()) {
            if (--cooldown > 0) return;
            startScan(mc, cfg);
            return;
        }

        for (int i = 0; i < CHUNKS_PER_TICK && !QUEUE.isEmpty(); i++) {
            scanChunk(mc.level, QUEUE.poll(), cfg);
        }
        if (QUEUE.isEmpty()) finish(mc, cfg);
    }

    private static void startScan(Minecraft mc, TracerConfig cfg) {
        Set<Block> blocks = new HashSet<>();
        for (Ore ore : Ore.values()) {
            if (cfg.isOn(ore)) for (Block b : ore.blocks) blocks.add(b);
        }
        active = blocks;
        scanBiome = cfg.isOn(Ore.DEEP_DARK);
        scanCave = cfg.isOn(Ore.BIG_CAVE);
        playerPos = mc.player.blockPosition();
        cooldown = RESCAN_DELAY_TICKS;
        BUILDING.clear();
        if (blocks.isEmpty() && !scanBiome && !scanCave) {
            results = List.of();
            return;
        }

        int pcx = mc.player.blockPosition().getX() >> 4;
        int pcz = mc.player.blockPosition().getZ() >> 4;
        int r = cfg.chunkRadius;
        List<Cell> cells = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++)
                cells.add(new Cell(pcx + dx, pcz + dz));
        cells.sort((a, b) -> Integer.compare(dist2(a, pcx, pcz), dist2(b, pcx, pcz)));
        QUEUE.addAll(cells);
    }

    private static int dist2(Cell c, int pcx, int pcz) {
        int dx = c.cx() - pcx, dz = c.cz() - pcz;
        return dx * dx + dz * dz;
    }

    private static void scanChunk(ClientLevel level, Cell cell, TracerConfig cfg) {
        LevelChunk chunk = level.getChunkSource().getChunkNow(cell.cx(), cell.cz());
        if (chunk == null) return;

        if (scanBiome) scanBiome(level, cell);
        if (scanCave) scanCave(level, chunk, cell);

        int up = cfg.lavaRange;
        int side = up > 3 ? 2 : 1;

        LevelChunkSection[] sections = chunk.getSections();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection section = sections[i];
            if (section == null || section.hasOnlyAir()) continue;
            if (!section.maybeHas(s -> active.contains(s.getBlock()))) continue;

            int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
            for (int y = 0; y < 16; y++)
                for (int z = 0; z < 16; z++)
                    for (int x = 0; x < 16; x++) {
                        BlockState state = section.getBlockState(x, y, z);
                        Block block = state.getBlock();
                        if (!active.contains(block)) continue;
                        pos.set((cell.cx() << 4) + x, baseY + y, (cell.cz() << 4) + z);
                        if (isExposed(level, pos)) {
                            BlockPos im = pos.immutable();
                            BUILDING.add(new Hit(im, Ore.of(block), nearLava(level, im, up, side), im, im, 1));
                        }
                    }
        }
    }


    /** Deep Dark pelo bioma que o servidor mandou: amostra alguns pontos do chunk. */
    private static void scanBiome(ClientLevel level, Cell cell) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int y = -52; y <= -4; y += 12) {
            if (y < level.getMinY()) continue;
            for (int dx = 2; dx < 16; dx += 4)
                for (int dz = 2; dz < 16; dz += 4) {
                    p.set((cell.cx() << 4) + dx, y, (cell.cz() << 4) + dz);
                    if (!level.getBiome(p).is(Biomes.DEEP_DARK)) continue;
                    double d = p.distSqr(playerPos);
                    if (d < bd) { bd = d; best = p.immutable(); }
                }
        }
        if (best == null) return;
        BlockPos min = new BlockPos(cell.cx() << 4, best.getY() - 2, cell.cz() << 4);
        BlockPos max = new BlockPos((cell.cx() << 4) + 15, best.getY() + 2, (cell.cz() << 4) + 15);
        BUILDING.add(new Hit(best, Ore.DEEP_DARK, false, min, max, 1));
    }

    /** Caverna grande: seção 16x16x16 debaixo da terra com muito ar (amostra 1 a cada 2 blocos). */
    private static void scanCave(ClientLevel level, LevelChunk chunk, Cell cell) {
        LevelChunkSection[] sections = chunk.getSections();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;

        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection s = sections[i];
            if (s == null || s.hasOnlyAir()) continue;
            int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
            if (baseY + 16 > 48) continue; // só cavernas de baixo (até Y 48)

            int air = 0, total = 0, nd = Integer.MAX_VALUE;
            int nx = 8, ny = 8, nz = 8;
            for (int y = 0; y < 16; y += 2)
                for (int z = 0; z < 16; z += 2)
                    for (int x = 0; x < 16; x += 2) {
                        total++;
                        if (!s.getBlockState(x, y, z).isAir()) continue;
                        air++;
                        int d = (x - 8) * (x - 8) + (y - 8) * (y - 8) + (z - 8) * (z - 8);
                        if (d < nd) { nd = d; nx = x; ny = y; nz = z; }
                    }
            if (air * 100 < total * 35) continue; // menos de 35% de ar: não é caverna grande

            p.set((cell.cx() << 4) + 8, baseY + 16, (cell.cz() << 4) + 8);
            if (level.canSeeSky(p)) continue; // a céu aberto, não é caverna

            BlockPos at = new BlockPos((cell.cx() << 4) + nx, baseY + ny, (cell.cz() << 4) + nz);
            double d = at.distSqr(playerPos);
            if (d < bd) { bd = d; best = at; }
        }
        if (best == null) return;
        BlockPos min = best.offset(-6, -6, -6);
        BlockPos max = best.offset(6, 6, 6);
        BUILDING.add(new Hit(best, Ore.BIG_CAVE, false, min, max, 1));
    }

    /** Deep Dark: só o mais perto. Caverna grande: até 3, afastadas e a mais de 24 blocos de você. */
    private static List<Hit> pickVirtual(List<Hit> virt, BlockPos me) {
        virt.sort((a, b) -> Double.compare(a.pos().distSqr(me), b.pos().distSqr(me)));
        List<Hit> out = new ArrayList<>();
        boolean deepDone = false;
        int caves = 0;
        for (Hit h : virt) {
            if (h.ore() == Ore.DEEP_DARK) {
                if (deepDone) continue;
                deepDone = true;
                out.add(h);
            } else if (h.ore() == Ore.BIG_CAVE) {
                if (caves >= 3 || h.pos().distSqr(me) < 24 * 24) continue;
                boolean tooClose = false;
                for (Hit o : out) {
                    if (o.ore() == Ore.BIG_CAVE && o.pos().distSqr(h.pos()) < 32 * 32) { tooClose = true; break; }
                }
                if (tooClose) continue;
                caves++;
                out.add(h);
            }
        }
        return out;
    }

    /** Lava ao lado (side) ou acima (up) do minério. */
    private static boolean nearLava(ClientLevel level, BlockPos pos, int up, int side) {
        BlockPos.MutableBlockPos n = new BlockPos.MutableBlockPos();
        for (int dx = -side; dx <= side; dx++)
            for (int dy = -1; dy <= up; dy++)
                for (int dz = -side; dz <= side; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    n.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz);
                    if (!level.hasChunkAt(n)) continue;
                    if (level.getBlockState(n).is(Blocks.LAVA)) return true;
                }
        return false;
    }

    private static boolean isExposed(ClientLevel level, BlockPos pos) {
        BlockPos.MutableBlockPos n = new BlockPos.MutableBlockPos();
        for (Direction d : Direction.values()) {
            n.setWithOffset(pos, d);
            if (!level.hasChunkAt(n)) continue;
            BlockState s = level.getBlockState(n);
            if (s.isAir() || !s.getFluidState().isEmpty()) return true;
        }
        return false;
    }

    private static void finish(Minecraft mc, TracerConfig cfg) {
        BlockPos me = mc.player.blockPosition();
        List<Hit> hits = new ArrayList<>();
        List<Hit> virt = new ArrayList<>();
        for (Hit h : BUILDING) (h.ore().isVirtual() ? virt : hits).add(h);
        BUILDING.clear();
        if (cfg.groupVeins) hits = cluster(hits, me);

        hits.sort((a, b) -> Double.compare(a.pos().distSqr(me), b.pos().distSqr(me)));
        int limit = cfg.onlyNearest ? 1 : cfg.maxLines;
        if (hits.size() > limit) hits = new ArrayList<>(hits.subList(0, limit));

        List<Hit> all = new ArrayList<>(hits);
        all.addAll(pickVirtual(virt, me));
        results = List.copyOf(all);
    }

    /** Junta minérios colados (mesmo tipo) numa veia só. */
    private static List<Hit> cluster(List<Hit> hits, BlockPos me) {
        Map<BlockPos, Hit> byPos = new HashMap<>();
        for (Hit h : hits) byPos.put(h.pos(), h);
        Set<BlockPos> seen = new HashSet<>();
        List<Hit> out = new ArrayList<>();

        for (Hit h : hits) {
            if (!seen.add(h.pos())) continue;
            ArrayDeque<BlockPos> q = new ArrayDeque<>();
            q.add(h.pos());
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
            int count = 0;
            boolean lava = false;
            BlockPos nearest = h.pos();
            double nd = Double.MAX_VALUE;

            while (!q.isEmpty()) {
                BlockPos p = q.poll();
                Hit c = byPos.get(p);
                count++;
                lava |= c.lava();
                minX = Math.min(minX, p.getX()); maxX = Math.max(maxX, p.getX());
                minY = Math.min(minY, p.getY()); maxY = Math.max(maxY, p.getY());
                minZ = Math.min(minZ, p.getZ()); maxZ = Math.max(maxZ, p.getZ());
                double d = p.distSqr(me);
                if (d < nd) { nd = d; nearest = p; }

                for (int dx = -1; dx <= 1; dx++)
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx == 0 && dy == 0 && dz == 0) continue;
                            BlockPos np = p.offset(dx, dy, dz);
                            Hit o = byPos.get(np);
                            if (o != null && o.ore() == h.ore() && seen.add(np)) q.add(np);
                        }
            }
            out.add(new Hit(nearest, h.ore(), lava,
                    new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ), count));
        }
        return out;
    }
}
