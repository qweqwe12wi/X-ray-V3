package com.example.oretracer;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.Vec3;

/** Linha + borda (cubo ou caixa da veia). Borda vermelha com X = lava perto. */
public final class TracerRenderer {
    private static final int LAVA_COLOR = 0xFFFF2A00;
    private static final double PAD = 0.002;
    private static boolean tickMode = false;

    private TracerRenderer() { }

    public static void init() {
        LevelRenderEvents.END_EXTRACTION.register(ctx -> {
            if (tickMode) return;
            try {
                draw(Minecraft.getInstance(), 0);
            } catch (Throwable t) {
                tickMode = true;
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!tickMode) return;
            try { draw(mc, 80); } catch (Throwable ignored) { }
        });
    }

    private static void draw(Minecraft mc, int persistMs) {
        TracerConfig cfg = TracerConfig.get();
        if (!cfg.enabled || mc.player == null) return;

        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        Vec3 start = mc.player.getEyePosition(pt).add(mc.player.getViewVector(pt).scale(0.6));

        float lw = cfg.lineWidth;
        float bw = cfg.boxWidth;
        float lavaW = bw + 3f;

        int count = 0;
        for (OreScanner.Hit hit : OreScanner.results()) {
            if (!cfg.isOn(hit.ore())) continue;
            if (!hit.ore().isVirtual() && count++ >= cfg.maxLines) continue;
            Ore o = hit.ore();
            int oreColor = 0xFF000000
                    | ((int) (o.r * 255) << 16)
                    | ((int) (o.g * 255) << 8)
                    | (int) (o.b * 255);

            line(start, Vec3.atCenterOf(hit.pos()), oreColor, lw, persistMs);
            if (hit.lava()) box(hit, LAVA_COLOR, lavaW, true, persistMs);
            else box(hit, oreColor, bw, false, persistMs);
        }
    }

    private static void line(Vec3 a, Vec3 b, int argb, float width, int persistMs) {
        var props = Gizmos.line(a, b, argb, width).setAlwaysOnTop();
        if (persistMs > 0) props.persistForMillis(persistMs);
    }

    private static void box(OreScanner.Hit h, int argb, float w, boolean cross, int ms) {
        double x0 = h.min().getX() - PAD, y0 = h.min().getY() - PAD, z0 = h.min().getZ() - PAD;
        double x1 = h.max().getX() + 1 + PAD, y1 = h.max().getY() + 1 + PAD, z1 = h.max().getZ() + 1 + PAD;

        Vec3 a = new Vec3(x0, y0, z0), b = new Vec3(x1, y0, z0);
        Vec3 c = new Vec3(x1, y0, z1), d = new Vec3(x0, y0, z1);
        Vec3 e = new Vec3(x0, y1, z0), f = new Vec3(x1, y1, z0);
        Vec3 g = new Vec3(x1, y1, z1), hh = new Vec3(x0, y1, z1);

        line(a, b, argb, w, ms); line(b, c, argb, w, ms); line(c, d, argb, w, ms); line(d, a, argb, w, ms);
        line(e, f, argb, w, ms); line(f, g, argb, w, ms); line(g, hh, argb, w, ms); line(hh, e, argb, w, ms);
        line(a, e, argb, w, ms); line(b, f, argb, w, ms); line(c, g, argb, w, ms); line(d, hh, argb, w, ms);

        if (cross) { // X no topo e na base = lava perto
            line(e, g, argb, w, ms); line(f, hh, argb, w, ms);
            line(a, c, argb, w, ms); line(b, d, argb, w, ms);
        }
    }
}
