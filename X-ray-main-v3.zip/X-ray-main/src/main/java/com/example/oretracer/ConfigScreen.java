package com.example.oretracer;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Tela 1: liga/desliga, máx. linhas, raio e minérios. */
public class ConfigScreen extends Screen {
    private static final int[] LINE_OPTIONS = {8, 16, 32, 64};

    private final Screen parent;

    public ConfigScreen(Screen parent) {
        super(Component.literal("Ore Tracer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        TracerConfig cfg = TracerConfig.get();
        int w = Math.min(this.width - 16, 320);
        int x0 = (this.width - w) / 2;
        int half = (w - 4) / 2;
        int h = 18;
        int step = 20;
        int y = 6;

        this.addRenderableWidget(new StringWidget(x0, y, w, 12, this.title, this.font));
        y += 16;

        this.addRenderableWidget(Button.builder(onLabel(cfg), b -> {
            cfg.enabled = !cfg.enabled;
            b.setMessage(onLabel(cfg));
        }).bounds(x0, y, half, h).build());

        this.addRenderableWidget(Button.builder(linesLabel(cfg), b -> {
            int next = LINE_OPTIONS[0];
            for (int i = 0; i < LINE_OPTIONS.length; i++) {
                if (LINE_OPTIONS[i] == cfg.maxLines) next = LINE_OPTIONS[(i + 1) % LINE_OPTIONS.length];
            }
            cfg.maxLines = next;
            b.setMessage(linesLabel(cfg));
        }).bounds(x0 + half + 4, y, half, h).build());
        y += step;

        this.addRenderableWidget(new RadiusSlider(x0, y, w, h, cfg));
        y += step + 2;

        Ore[] ores = Ore.values();
        for (int i = 0; i < ores.length; i++) {
            Ore ore = ores[i];
            int bx = x0 + (i % 2) * (half + 4);
            int by = y + (i / 2) * step;
            this.addRenderableWidget(Button.builder(oreLabel(cfg, ore), b -> {
                cfg.toggle(ore);
                b.setMessage(oreLabel(cfg, ore));
            }).bounds(bx, by, half, h).build());
        }
        y += ((ores.length + 1) / 2) * step + 2;

        this.addRenderableWidget(Button.builder(Component.literal("Mais opções"), b -> {
            if (this.minecraft != null) this.minecraft.setScreenAndShow(new OptionsScreen(this));
        }).bounds(x0, y, half, h).build());

        this.addRenderableWidget(Button.builder(Component.literal("Concluir"), b -> this.onClose())
                .bounds(x0 + half + 4, y, half, h).build());
    }

    private static Component onLabel(TracerConfig cfg) {
        return Component.literal("Tracer: " + (cfg.enabled ? "LIGADO" : "DESLIGADO"))
                .withStyle(cfg.enabled ? ChatFormatting.GREEN : ChatFormatting.RED);
    }

    private static Component linesLabel(TracerConfig cfg) {
        return Component.literal("Máx. linhas: " + cfg.maxLines);
    }

    private static Component oreLabel(TracerConfig cfg, Ore ore) {
        boolean on = cfg.isOn(ore);
        return Component.literal((on ? "[X] " : "[  ] ") + ore.label)
                .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.GRAY);
    }

    @Override
    public void onClose() {
        TracerConfig.get().save();
        OreScanner.requestRescan();
        if (this.minecraft != null) this.minecraft.setScreenAndShow(this.parent);
    }

    private static class RadiusSlider extends AbstractSliderButton {
        private final TracerConfig cfg;

        RadiusSlider(int x, int y, int width, int height, TracerConfig cfg) {
            super(x, y, width, height, Component.empty(),
                    (cfg.chunkRadius - TracerConfig.MIN_RADIUS)
                            / (double) (TracerConfig.MAX_RADIUS - TracerConfig.MIN_RADIUS));
            this.cfg = cfg;
            this.updateMessage();
        }

        @Override
        protected void updateMessage() {
            if (cfg == null) return;
            this.setMessage(Component.literal("Raio de varredura: " + cfg.chunkRadius + " chunks"));
        }

        @Override
        protected void applyValue() {
            cfg.chunkRadius = TracerConfig.MIN_RADIUS
                    + (int) Math.round(this.value * (TracerConfig.MAX_RADIUS - TracerConfig.MIN_RADIUS));
        }
    }
}
