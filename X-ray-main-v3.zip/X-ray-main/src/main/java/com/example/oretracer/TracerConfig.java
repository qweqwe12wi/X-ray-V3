package com.example.oretracer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

/** Configuração salva em config/oretracer.json. */
public final class TracerConfig {
    public static final int MIN_RADIUS = 1;
    public static final int MAX_RADIUS = 16;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static TracerConfig instance;

    public boolean enabled = true;
    public int chunkRadius = 4;
    public int maxLines = 16;
    public Set<String> ores = new LinkedHashSet<>(Set.of(Ore.DIAMOND.name()));

    // novas opções
    public int lineWidth = 3;
    public int boxWidth = 4;
    public boolean onlyNearest = false;
    public boolean groupVeins = true;
    public boolean showDistance = true;
    public boolean dangerAlert = true;
    public int lavaRange = 3;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("oretracer.json");
    }

    public static TracerConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        TracerConfig cfg = null;
        try {
            Path f = file();
            if (Files.exists(f)) cfg = GSON.fromJson(Files.readString(f), TracerConfig.class);
        } catch (Exception ignored) { }
        if (cfg == null) cfg = new TracerConfig();
        if (cfg.ores == null) cfg.ores = new LinkedHashSet<>();
        cfg.chunkRadius = Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, cfg.chunkRadius));
        cfg.maxLines = Math.max(1, Math.min(256, cfg.maxLines));
        cfg.lineWidth = Math.max(1, Math.min(10, cfg.lineWidth));
        cfg.boxWidth = Math.max(1, Math.min(10, cfg.boxWidth));
        cfg.lavaRange = Math.max(1, Math.min(10, cfg.lavaRange));
        instance = cfg;
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(this));
        } catch (IOException ignored) { }
    }

    public boolean isOn(Ore ore) {
        return ores.contains(ore.name());
    }

    public void toggle(Ore ore) {
        if (!ores.remove(ore.name())) ores.add(ore.name());
    }
}
