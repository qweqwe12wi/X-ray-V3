package com.example.oretracer;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;

/** Menu: tecla K ou comando /oretracer (útil no celular). */
public class OreTracerClient implements ClientModInitializer {
    public static final String MOD_ID = "oretracer";

    private static KeyMapping menuKey;
    private static int openDelay = -1;

    @Override
    public void onInitializeClient() {
        TracerConfig.load();

        menuKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.oretracer.menu", InputConstants.KEY_K, KeyMapping.Category.MISC));

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommands.literal("oretracer").executes(ctx -> {
                    openDelay = 3; // espera o chat fechar
                    return 1;
                })));

        TracerRenderer.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.consumeClick()) openDelay = 0;
            if (openDelay >= 0) {
                if (openDelay-- == 0 && mc.player != null) {
                    mc.setScreenAndShow(new ConfigScreen(null));
                }
            }
            OreScanner.tick(mc);
            Alerts.tick(mc);
        });
    }
}
