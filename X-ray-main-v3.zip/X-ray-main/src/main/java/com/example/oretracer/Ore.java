package com.example.oretracer;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

import java.util.HashMap;
import java.util.Map;

/** Minérios selecionáveis no menu. */
public enum Ore {
    DIAMOND("Diamante", 0x33E5FF, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE),
    ANCIENT_DEBRIS("Ancient Debris", 0xC8763C, Blocks.ANCIENT_DEBRIS),
    EMERALD("Esmeralda", 0x17DD62, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE),
    GOLD("Ouro", 0xFFD700, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE),
    IRON("Ferro", 0xD8AF93, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE),
    COPPER("Cobre", 0xE77C56, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE),
    COAL("Carvão", 0x9A9A9A, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE),
    REDSTONE("Redstone", 0xFF2222, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE),
    LAPIS("Lápis", 0x3355FF, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE),
    QUARTZ("Quartzo", 0xEEEEEE, Blocks.NETHER_QUARTZ_ORE),
    ANCIENT_CITY("Cidade Antiga", 0xB04BFF, Blocks.REINFORCED_DEEPSLATE, Blocks.SOUL_LANTERN, Blocks.DEEPSLATE_TILES, Blocks.CRACKED_DEEPSLATE_TILES, Blocks.DEEPSLATE_BRICKS),
    SCULK("Sculk", 0x00B3A4, Blocks.SCULK, Blocks.SCULK_CATALYST, Blocks.SCULK_SHRIEKER, Blocks.SCULK_SENSOR),
    // "Minérios virtuais": sem bloco, detectados por bioma / formato da caverna.
    DEEP_DARK("Deep Dark (bioma)", 0x66AAFF),
    BIG_CAVE("Caverna grande", 0xFF66CC);

    private static final Map<Block, Ore> BY_BLOCK = new HashMap<>();
    static {
        for (Ore o : values()) for (Block b : o.blocks) BY_BLOCK.put(b, o);
    }

    public final String label;
    public final float r, g, b;
    public final Block[] blocks;

    Ore(String label, int rgb, Block... blocks) {
        this.label = label;
        this.r = ((rgb >> 16) & 0xFF) / 255f;
        this.g = ((rgb >> 8) & 0xFF) / 255f;
        this.b = (rgb & 0xFF) / 255f;
        this.blocks = blocks;
    }

    /** Opções que não procuram bloco (Deep Dark pelo bioma, caverna grande pelo ar). */
    public boolean isVirtual() {
        return blocks.length == 0;
    }

    /** @return o minério correspondente ao bloco, ou null. */
    public static Ore of(Block block) {
        return BY_BLOCK.get(block);
    }
}
