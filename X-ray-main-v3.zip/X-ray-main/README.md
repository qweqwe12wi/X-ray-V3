# Ore Tracer (Fabric, Minecraft 26.3)

Desenha uma linha (através das paredes) até minérios **expostos ao ar/fluido**.
Só usa blocos que o cliente já recebeu; não tenta burlar Anti-Xray de servidores.
Use apenas onde ESP/tracers forem permitidos.

## Menu
- Tecla **K** (configurável em Controles) ou comando **/oretracer** (melhor no celular).
- Liga/desliga, máx. de linhas (8/16/32/64), raio da varredura (1–16 chunks) e filtro de minérios.
- Config salva em `config/oretracer.json`.

## Compilar (sem PC)
1. Suba o conteúdo desta pasta para um repositório no GitHub.
2. Aba **Actions** → workflow **build** → quando terminar, baixe o artefato **oretracer-jar**.
3. Coloque o `.jar` (sem `-sources`) na pasta `mods` junto com o Fabric API.

## Requisitos
Java 25, Fabric Loader >= 0.19.3, Fabric API 0.161.0+26.3 (ou mais novo para 26.3).

## Se o build falhar
Confira versões em https://fabricmc.net/develop (o site pode estar fora do ar) ou no
repositório FabricMC/fabric-example-mod (branch 26.3 / 26.2) e ajuste `gradle.properties`.
